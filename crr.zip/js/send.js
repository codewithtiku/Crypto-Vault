document.getElementById('btn-send').addEventListener('click', SendFunc);
function SendFunc(){
    document.getElementById('send-wa').value = "";
    document.getElementById('send-sa').value = "";
}