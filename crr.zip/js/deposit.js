document.getElementById('deposit').addEventListener('click', DepositFunc);
function DepositFunc(){
    document.querySelector('.i-d').value = "";
}